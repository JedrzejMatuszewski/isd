﻿using ISD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISD.Consts
{
    public class Const
    {
        public List<string> Keywords { get; set; }
        public List<WordIdPair> ShopItems { get; set; }


        public Const()
        {
            Keywords = new List<string>()
            {
                "wędka",
                "połów",
                "ryb", //ryba
                "kołowrotek",
                "spławik",
                "karp",
                "przynęta",
                "haczyk",
                "spławik",
                "jezioro",
                "rzeka",
                "woda"
            };

            ShopItems = new List<WordIdPair>()
            {
                new WordIdPair
                {
                    Id = 1,
                    Word = "wędka"
                },
                new WordIdPair
                {
                    Id = 2,
                    Word = "kołowrotek"
                },
                new WordIdPair
                {
                    Id = 3,
                    Word = "ryba"
                },
                new WordIdPair
                {
                    Id = 4,
                    Word = "przynęta"
                },
                new WordIdPair
                {
                    Id = 5,
                    Word = "spławik"
                },
            };

        }

        public List<WordCountPair> GetWordCountPairs()
        {
            return this.Keywords.Select(x =>
                new WordCountPair
                {
                    Word = x,
                    Count = 0
                }).ToList();
        }

        public List<WordSelected> GetWorldSelectedEmptyPairs()
        {
            return this.ShopItems.Select(x =>
                new WordSelected
                {
                    Word = x.Word,
                    Selected = 0
                }).ToList();
        }
    }

}
