﻿using ISD.Consts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISD.Models
{
    public class DModel
    {
        public int ArticleId { get; set; }
        public List<WordCountPair> WordCountPairs { get; set; }
        //{
        //    new KeyValuePair<string, int>("wędka", 0),
        //    new KeyValuePair<string, int>("połów", 0),
        //    new KeyValuePair<string, int>("ryb", 0),
        //    new KeyValuePair<string, int>("kołowrotek", 0),
        //    new KeyValuePair<string, int>("spławik", 0),
        //    new KeyValuePair<string, int>("karp", 0),
        //    new KeyValuePair<string, int>("przynęta", 0),
        //    new KeyValuePair<string, int>("haczyk", 0),
        //    new KeyValuePair<string, int>("spławik", 0),
        //    new KeyValuePair<string, int>("jezioro", 0),
        //    new KeyValuePair<string, int>("rzeka", 0),
        //    new KeyValuePair<string, int>("woda", 0),
        //};

        public DModel()
        {
            WordCountPairs = new Const().GetWordCountPairs();
        }
    }
}