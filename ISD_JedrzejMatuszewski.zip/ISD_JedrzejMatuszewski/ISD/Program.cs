﻿using ConsoleTables;
using ISD.Consts;
using ISD.Models;
using ISD.Shop;
using System;

namespace ISD // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var path = @"C:\Users\jedrz\source\repos\ISD\Articles\";
            var articles = new List<DModel>();

            for (int i = 0; i < 12; i++)
            {
                var allText = System.IO.File.ReadAllText($@"{path}\{i}\{i}.txt");
                var articleModel = new DModel { ArticleId = i };

                foreach (var textItem in allText.Split())
                {
                    foreach(var dataPair in articleModel.WordCountPairs)
                    {
                        if (textItem.Contains(dataPair.Word))
                        {
                            dataPair.Count++;
                        }
                    }
                }

                articles.Add(articleModel);
            }

            PrintArticles(articles);

            PrintEuclideanDistance(articles);
            PrintManhattanDistance(articles);
            PrintCosineDistance(articles);
            PrintCzebyszewDistance(articles);

            new ISDShop();

        }

        static void PrintArticles(List<DModel> articles)
        {
            var table = new ConsoleTable("data/term", 
                "t0", "t1", "t2", "t3", "t4", "t5", 
                "t6", "t7", "t8", "t9", "t10", "t11");
            
            foreach (var article in articles.OrderBy(x=> x.ArticleId))
            {

                var listToPrint = new List<object> { "d"+ article.ArticleId };
                listToPrint.AddRange(article.WordCountPairs.Select(x => (object)x.Count));

                table.AddRow(listToPrint.ToArray());
            }

            table.Write();
            Console.WriteLine();

        }


        static void PrintEuclideanDistance(List<DModel> articles)
        {
            var datasets = GetDatasets(articles);

            int size = articles.Count;
            var result = new double[size,size];

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    var dataset1 = datasets[i];
                    var dataset2 = datasets[j];

                    double sum = 0;
                    for (int x = 0; x < size; x++)
                    {
                        sum += Math.Pow(dataset1[x] - dataset2[x], 2);
                    }

                    result[i,j] = Math.Sqrt(sum);

                }
            }


            Console.WriteLine("Odległość Euklidesowa");
            PrintDatasets(result);
        }
        static void PrintManhattanDistance(List<DModel> articles)
        {
            var datasets = GetDatasets(articles);

            int size = articles.Count;
            var result = new double[size, size];

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    var dataset1 = datasets[i];
                    var dataset2 = datasets[j];

                    double sum = 0;
                    for (int x = 0; x < size; x++)
                    {
                        sum += Math.Abs(dataset1[x] - dataset2[x]);
                    }

                    result[i, j] = Math.Sqrt(sum);

                }
            }


            Console.WriteLine("Odległość Manhattan");
            PrintDatasets(result);
        }
        static void PrintCosineDistance(List<DModel> articles)
        {
            var datasets = GetDatasets(articles);

            int size = articles.Count;
            var result = new double[size, size];

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    var dataset1 = datasets[i];
                    var dataset2 = datasets[j];

                    //vector product
                    double sum = 0;

                    //lenght
                    double len1 = 0;
                    double len2 = 0;

                    for (int x = 0; x < size; x++)
                    {
                        sum += dataset1[x] * dataset2[x];

                        len1 += Math.Pow(dataset1[x], 2);
                        len2 += Math.Pow(dataset2[x], 2);
                    }
                    len1 = Math.Sqrt(len1);
                    len2 = Math.Sqrt(len2);

                    result[i, j] = Math.Sqrt(sum/(len1 * len2));

                }
            }


            Console.WriteLine("Odległość Kosinusów");
            PrintDatasets(result);
        }
        static void PrintCzebyszewDistance(List<DModel> articles)
        {
            var datasets = GetDatasets(articles);

            int size = articles.Count;
            var result = new double[size, size];

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    var dataset1 = datasets[i];
                    var dataset2 = datasets[j];

                    double max = 0;

                    for (int x = 0; x < size; x++)
                    {
                        var temp = Math.Abs(dataset1[x] - dataset2[x]);

                        if (temp > max)
                            max = temp;
                    }

                    result[i, j] = max;

                }
            }


            Console.WriteLine("Odległość Czebyszewa");
            PrintDatasets(result);
        }



        static List<List<double>> GetDatasets(List<DModel> articles)
        {
            var datasets = new List<List<double>>();
            foreach (var article in articles)
            {
                var dataset = article.WordCountPairs.Select(x => (double)x.Count).ToList();
                datasets.Add(dataset);
            }

            return datasets;
        }
        static void PrintDatasets(double[,] datasets)
        {
            var size = 12;

            string[] headers = new string[size + 1];
            for (int i = 1; i < size+1; i++)
            {
                var x = i - 1;

                headers[i] = "d" + i;

            }

            var table = new ConsoleTable(headers);

            for (int i = 0; i < size; i++)
            {
                var rowList = new List<string>();
                rowList.Add("d" + i);
                for (int j = 0; j < size; j++)
                {
                    rowList.Add(datasets[i,j].ToString("F"));
                }

                object[] row = rowList.ToArray();
                table.AddRow(row);
            }

            table.Write();
            Console.WriteLine();

            //Print2DArray<double>(datasets);

        }

        public static void Print2DArray<T>(T[,] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    Console.Write(matrix[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }
    }
}