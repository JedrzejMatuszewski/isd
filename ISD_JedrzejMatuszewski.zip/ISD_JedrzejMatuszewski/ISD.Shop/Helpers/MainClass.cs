﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ISD.Shop
{
    public class MainClass
    {
        public string[] Terms { get; set; }
        public List<int> ListOfTfmCells { get; set; }
        public List<Transaction> ListOfTfmCellsData { get; set; }

        public TableGenerator TableGenerator { get; set; }

        public MainClass()
        {
            Terms = new string[] {  };

            ListOfTfmCells = new List<int>();
            ListOfTfmCellsData = new List<Transaction>();

            var allFileNames = new string[] { };
            TableGenerator = new TableGenerator(allFileNames, Directory.GetCurrentDirectory(), Terms);
        }
    }
}
