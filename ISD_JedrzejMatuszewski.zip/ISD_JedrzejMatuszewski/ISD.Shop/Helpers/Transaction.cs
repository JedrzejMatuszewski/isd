﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISD.Shop
{
    public class Transaction
    {
        public Transaction(double[] list)
        {
            List = list;
        }

        public Transaction(List<double> list)
        {
            List = list.ToArray();
        }

        public double[] List { get; }

        public string[] GetStringList()
        {
            return List.Select(p => p.ToString()).ToArray();
        }
    }
}
