﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISD.Shop
{

    public class ShopSystem
    {
        public List<Transaction> ListOfTransactions { get; set; }

        public ShopSystem()
        {

        }

        public List<int> AddAndShowRecommendedItems(Tuple<int, int>[] Transaction, double[] baselist, string name)
        {
            AddTransaction(Transaction, baselist);
            var distance = GenerateDistance(name);
            var smalestDistance = Find3Smalest(distance);
            var itemsToSugest = IndexToShopItems(smalestDistance);
            return itemsToSugest;
        }

        public List<int> IndexToShopItems(List<int> listOfIndex)
        {
            var listOfItemsIndex = new List<int>();
            foreach (var i in listOfIndex)
            {
                var itemList = ListOfTransactions[i];
                listOfItemsIndex.AddRange(GetItemsPosition(itemList));
            }
            var myset = listOfItemsIndex.Distinct().OrderBy(p => p).ToList();
            return myset;
        }

        public List<int> GetItemsPosition(Transaction itemList)
        {
            var listOfItemsIndex = new List<int>();
            var iterator = 0;
            foreach (var item in itemList.List)
            {
                if (item != 0)
                {
                    listOfItemsIndex.Add(iterator);
                }
                iterator++;
            }

            return listOfItemsIndex;
        }

        public List<int> Find3Smalest(List<Transaction> data)
        {
            var newData = data.Last().List.OrderBy(p => p).ToList();
            var listElements = newData.ToArray()[1..4];
            var indexList = new List<int>();
            var sortList = data.Last().List.OrderBy(p => p).ToList();

            foreach (var item in listElements)
            {
                var itemToAppend = Array.IndexOf(data.Last().List, item);
                indexList.Add(itemToAppend);
            }

            return indexList;
        }

        public void AddTransaction(Tuple<int, int>[] transaction, double[] baselist)
        {
            var varToShow = ListOfTransactions.Count() + 1;
            var baseList = new Transaction(baselist);
            foreach (var item in transaction)
            {
                var itemPosition = item.Item1 - 1;
                if (baseList.List[itemPosition] == 0)
                {
                    baseList.List[itemPosition] = item.Item2;
                }
                else
                {
                    baseList.List[itemPosition] += item.Item2;
                }
            }
            ListOfTransactions.Add(baseList);
        }

        public List<Transaction> GenerateDistance(string name)
        {
            var cos = new MainClass();
            var generator = new GenerateDistances(cos.TableGenerator);

            var euclides = generator.GenerateEuclidesDistance(ListOfTransactions, false);
            cos.TableGenerator.TextTableEnhanced(euclides, $"{name}-euclides.txt", GenerateLineNames(ListOfTransactions.Count));

            var cosine = generator.GenerateCosineDistance(ListOfTransactions, false);
            cos.TableGenerator.TextTableEnhanced(cosine, $"{name}-cosine.txt", GenerateLineNames(ListOfTransactions.Count));

            var manhatan = generator.GenerateManhatanDistance(ListOfTransactions, false);
            cos.TableGenerator.TextTableEnhanced(manhatan, $"{name}-manhatan.txt", GenerateLineNames(ListOfTransactions.Count));

            var chebyshev = generator.GenerateChebysheveDistance(ListOfTransactions, false);
            cos.TableGenerator.TextTableEnhanced(chebyshev, $"{name}-chebyshev.txt", GenerateLineNames(ListOfTransactions.Count));

            return chebyshev;
        }

        public List<string> GenerateLineNames(int amount)
        {
            var listOfNames = new List<string>();

            foreach (var num in Enumerable.Range(0, amount))
            {
                listOfNames.Add($"d{num}");
            }

            return listOfNames;
        }
    }
}
