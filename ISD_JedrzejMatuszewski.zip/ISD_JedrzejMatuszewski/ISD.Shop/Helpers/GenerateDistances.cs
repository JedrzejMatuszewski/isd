﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISD.Shop
{
    public class GenerateDistances
    {
        private readonly TableGenerator tableGenerator;
        private readonly List<string> listOfTfmCells = new List<string>();

        public GenerateDistances(TableGenerator tableGenerator)
        {
            this.tableGenerator = tableGenerator;
        }

        public List<Transaction> GenerateEuclidesDistance(List<Transaction> ListOfTfmCellsData, bool printTable)
        {
            var calcObject = new CalcDistances();
            var iterator = 0;
            var biggerOutputList = new List<Transaction>();
            foreach (var i in ListOfTfmCellsData)
            {
                var outputList = new List<double>();
                foreach (var k in ListOfTfmCellsData)
                {
                    outputList.Add(calcObject.CalcEuclides(i.List, k.List));
                }
                iterator += 1;
                biggerOutputList.Add(new Transaction(outputList));
            }
            if (printTable)
            {
                tableGenerator.TextTable(biggerOutputList, "Euclides.txt");
            }
            return biggerOutputList;
        }

        public List<Transaction> GenerateCosineDistance(List<Transaction> ListOfTfmCellsData, bool printTable)
        {
            var calcObject = new CalcDistances();
            var iterator = 0;
            var biggerOutputList = new List<Transaction>();
            foreach (var i in ListOfTfmCellsData)
            {
                var outputList = new List<double>();
                foreach (var k in ListOfTfmCellsData)
                {
                    outputList.Add(calcObject.CalcCosine(i.List, k.List));
                }
                iterator += 1;
                biggerOutputList.Add(new Transaction(outputList));
            }
            if (printTable)
            {
                tableGenerator.TextTable(biggerOutputList, "Cosine.txt");
            }
            return biggerOutputList;
        }

        public List<Transaction> GenerateChebysheveDistance(List<Transaction> ListOfTfmCellsData, bool printTable = true)
        {
            var calcObject = new CalcDistances();
            var iterator = 0;
            var biggerOutputList = new List<Transaction>();
            foreach (var i in ListOfTfmCellsData)
            {
                var outputList = new List<double>();
                foreach (var k in ListOfTfmCellsData)
                {
                    outputList.Add(calcObject.CalcChebyshev(i.List, k.List));
                }
                iterator += 1;
                biggerOutputList.Add(new Transaction(outputList));
            }
            if (printTable)
            {
                tableGenerator.TextTable(biggerOutputList, "Chebyshev.txt");
            }
            return biggerOutputList;
        }

        public List<Transaction> GenerateManhatanDistance(List<Transaction> ListOfTfmCellsData, bool printTable = true)
        {
            var calcObject = new CalcDistances();
            var iterator = 0;
            var biggerOutputList = new List<Transaction>();
            foreach (var i in ListOfTfmCellsData)
            {
                var outputList = new List<double>();
                foreach (var k in ListOfTfmCellsData)
                {
                    outputList.Add(calcObject.CalcManhattan(i.List, k.List));
                }
                iterator += 1;
                biggerOutputList.Add(new Transaction(outputList));
            }
            if (printTable)
            {
                tableGenerator.TextTable(biggerOutputList, "Manhatan.txt");
            }
            return biggerOutputList;
        }
    }
}
