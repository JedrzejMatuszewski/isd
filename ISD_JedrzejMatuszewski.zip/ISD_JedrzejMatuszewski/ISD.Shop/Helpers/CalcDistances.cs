﻿using MathNet.Numerics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISD.Shop
{
    public class CalcDistances
    {
        public double CalcCosine(double[] list1, double[] list2)
        {
            var res = Distance.Cosine(list1, list2);

            return Math.Round(res, 2, MidpointRounding.AwayFromZero);
        }

        public double CalcEuclides(double[] list1, double[] list2)
        {
            var res = Distance.Euclidean(list1, list2);

            return Math.Round(res, 2, MidpointRounding.AwayFromZero);
        }

        public double CalcChebyshev(double[] list1, double[] list2)
        {
            return Distance.Chebyshev(list1, list2);
        }

        public double CalcManhattan(double[] list1, double[] list2)
        {
            return Distance.Manhattan(list1, list2);
        }

        public virtual object CaclPowDistance(double[] list1, double[] list2, int p, int r)
        {
            double difrence = 0;
            double poweredDifference = 0;

            foreach (var i in Enumerable.Range(0, list1.Count()))
            {
                difrence += Math.Abs(list1[i] - list2[i]);
                poweredDifference = Math.Pow(difrence, p);
            }

            if (poweredDifference == 0)
            {
                return poweredDifference;
            }

            return Math.Pow(poweredDifference, 1 / r);
        }
    }
}
