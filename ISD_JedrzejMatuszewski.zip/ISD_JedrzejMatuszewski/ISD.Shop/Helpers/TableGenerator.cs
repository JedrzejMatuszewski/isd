﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ConsoleTables;

namespace ISD.Shop
{
    public class TableGenerator
    {
        public string[] AllFileNames { get; }
        public string ScriptDir { get; }
        public string[] Terms { get; }

        public TableGenerator(string[] allFileNames, string scriptDir, string[] terms)
        {
            AllFileNames = allFileNames;
            ScriptDir = scriptDir;
            Terms = terms;
        }

        public void TfmTextTable(List<Transaction> dataToShow, string fileName)
        {
            var fieldNames = new List<string>() { "Data / Term" };
            fieldNames.AddRange(Terms);

            var table = new ConsoleTable(fieldNames.ToArray());
            var iterator = 0;
            foreach (var row in dataToShow)
            {
                var rowToAdd = new List<string>() { AllFileNames[iterator] };
                rowToAdd.AddRange(row.GetStringList());

                table.AddRow(rowToAdd.ToArray());
                iterator++;
            }

            var pathToSave = $"{ScriptDir}\\Raport\\{fileName}";

            File.WriteAllText(pathToSave, table.ToString());
        }

        public void TextTable(List<Transaction> dataToShow, string fileName)
        {
            var fieldNames = new List<string>() { "Data / Data" };
            fieldNames.AddRange(AllFileNames);

            var table = new ConsoleTable(fieldNames.ToArray());
            var iterator = 0;
            foreach (var row in dataToShow)
            {
                var rowToAdd = new List<string>() { AllFileNames[iterator] };
                rowToAdd.AddRange(row.GetStringList());

                table.AddRow(rowToAdd.ToArray());
                iterator++;
            }

            var pathToSave = $"{ScriptDir}\\Raport\\{fileName}";

            File.WriteAllText(pathToSave, table.ToString());
        }

        public string TextTableEnhanced(List<Transaction> dataToShow, string fileName, List<string> names)
        {
            var fieldNames = new List<string>() { "Data / Data" };
            fieldNames.AddRange(names);

            var table = new ConsoleTable(fieldNames.ToArray());
            var iterator = 0;
            foreach (var row in dataToShow)
            {
                var rowToAdd = new List<string>() { names[iterator] };
                rowToAdd.AddRange(row.GetStringList());

                table.AddRow(rowToAdd.ToArray());
                iterator++;
            }

            var pathToSave = $"{ScriptDir}\\Raport\\{fileName}";

            File.WriteAllText(pathToSave, table.ToString());

            return table.ToString();
        }

        public static void ShopTableToConsole(List<Transaction> dataToShow)
        {
            if (!dataToShow.Any())
            {
                return;
            }

            var fieldNames = new string[]
            {
                "",
                "1.wędka",
                "2.kołowrotek",
                "3.ryba",
                "4.przynęta",
                "5.spławik"
            };

            var rowNames = GenerateLineNames(dataToShow.Count);

            var table = new ConsoleTable(fieldNames.ToArray());
            var iterator = 0;
            foreach (var row in dataToShow)
            {
                var rowToAdd = new List<string>() { rowNames[iterator] };
                rowToAdd.AddRange(row.GetStringList());

                table.AddRow(rowToAdd.ToArray());
                iterator++;
            }

            table.Write();
        }

        public static void StudentTableToConsole(List<Transaction> dataToShow)
        {
            if (!dataToShow.Any())
            {
                return;
            }

            var fieldNames = new string[]
            {
                "", "1.java", "2.python", "3.vue", "4.angular", "5.reactjs",
                "6.angular", "7.visualstudiocode", "8.dotnet", "9.iddlej idea", "10.vs code",
                "11.piwo", "12.tv", "13.silownia", "14.tenis", "15. hokej",
                "16. pilka nozna", "17. koszykowka", "18. siatkówka", "19. spacer", "20. gra"
            };

            var rowNames = GenerateLineNames(dataToShow.Count);

            var table = new ConsoleTable(fieldNames.ToArray());
            var iterator = 0;
            foreach (var row in dataToShow)
            {
                var rowToAdd = new List<string>() { rowNames[iterator] };
                rowToAdd.AddRange(row.GetStringList());

                table.AddRow(rowToAdd.ToArray());
                iterator++;
            }

            table.Write();
        }

        private static List<string> GenerateLineNames(int amount)
        {
            var listOfNames = new List<string>();

            foreach (var num in Enumerable.Range(0, amount))
            {
                listOfNames.Add($"d{num}");
            }

            return listOfNames;
        }
    }
}
