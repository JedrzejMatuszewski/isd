﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ISD.Shop
{
    public class DataItem
    {
        public string DataName { get; set; }

        public string DataPath { get; set; }

        public DataItem(string dataName, string dataPath)
        {
            DataName = dataName;
            DataPath = dataPath;
        }
    }
}
