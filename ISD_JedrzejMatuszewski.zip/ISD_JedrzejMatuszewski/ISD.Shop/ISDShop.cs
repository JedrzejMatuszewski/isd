﻿
using ConsoleTables;

namespace ISD.Shop;

public class ISDShop
{
    public ISDShop()
    {
        Main();
    }

    private static ShopSystem shopSystem = new ShopSystem();
    private static string[] productNames = new string[]
        {
            "",
            "1.wędka",
            "2.kołowrotek",
            "3.ryba",
            "4.przynęta",
            "5.spławik"
        };

    private static string[] test3Names = new string[]
        {
            "", "1.java", "2.python", "3.vue", "4.angular", "5.reactjs",
            "6.angular", "7.visualstudiocode", "8.dotnet", "9.iddlej idea", "10.vs code",
            "11.piwo", "12.tv", "13.silownia", "14.tenis", "15. hokej",
            "16. pilka nozna", "17. koszykowka", "18. siatkówka", "19. spacer", "20. gra"
        };

    static void Main()
    {
        //shop
        #region Shop
        var shopTransactions = new List<Transaction>() 
        {
            new Transaction(new double[] { 1, 5, 2, 1, 3 }),
            new Transaction(new double[] { 1, 3, 0, 0, 0 }),
            new Transaction(new double[] { 1, 5, 0, 0, 1 }),
            new Transaction(new double[] { 1, 8, 0, 0, 0 }),
            new Transaction(new double[] { 1, 9, 0, 0, 0 }),
            new Transaction(new double[] { 0, 0, 0, 0, 4 }),
            new Transaction(new double[] { 0, 0, 0, 0, 0 }),
            new Transaction(new double[] { 0, 0, 2, 1, 0 }),
            new Transaction(new double[] { 0, 0, 2, 2, 0 }),
            new Transaction(new double[] { 0, 0, 3, 1, 0 }) 
        };

        shopSystem.ListOfTransactions = shopTransactions;

        string exit = "";
        while (exit != "0")
        {
            TableGenerator.ShopTableToConsole(shopTransactions);
            TableOfProduct();
            var selectedItems = ChoseItemsToBuy();
            List<int> sugestion = shopSystem.AddAndShowRecommendedItems(selectedItems, new double[] { 0, 0, 0, 0, 0 }, "Shop");
            SugestItem(sugestion, productNames);
            Console.WriteLine("Wpisz 0 aby opuścić sklep");
            exit = Console.ReadLine();
        }
        #endregion

        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine();

        //Dobry - zły
        #region GoodBad
        Console.WriteLine("Dobry (d0): (1, 5, 2, 1, 3)");
        Console.WriteLine("Zły (d1): (1, 3, 0, 0, 0)");
        var input = shopSystem.ListOfTransactions.Last();

        var D1 = new List<Transaction>
        {
            new Transaction(shopTransactions[0].List),
            new Transaction(input.List)
        };

        Console.WriteLine("D1(dx, d0): D1.txt");
        var res1 = GenerateDistance(D1, "Dobry_D1");

        var D2 = new List<Transaction>
        {
            new Transaction(shopTransactions[1].List),
            new Transaction(input.List)
        };

        Console.WriteLine("D2(dx, d1): D2.txt");
        var res2 = GenerateDistance(D2, "Zły_D2");

        var good = res1.First().List[1];
        var bad = res2.First().List[1];

        if(good < bad)
        {
            Console.WriteLine("Wprowadzony rekord jest dobry!");
        }
        else
        {
            Console.WriteLine("Wprowadzony rekord jest zły!");
        }

        #endregion


        Console.WriteLine();
        Console.WriteLine();
        Console.WriteLine();

        //Uczniowie ankieta

        var studentTransactions = new List<Transaction>() 
        {
            new Transaction(new double[] { 0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0 }),
            new Transaction(new double[] { 1, 1, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1 }),
            new Transaction(new double[] { 0, 1, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 0, 0, 0 }),
            new Transaction(new double[] { 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0 }),
            new Transaction(new double[] { 1, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1 }),
            new Transaction(new double[] { 0, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0 }),
            new Transaction(new double[] { 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1 }),
            new Transaction(new double[] { 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0 }),
            new Transaction(new double[] { 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1 }),
            new Transaction(new double[] { 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1, 1 }),
            new Transaction(new double[] { 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1 }),
            new Transaction(new double[] { 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0 }),
            new Transaction(new double[] { 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1 }),
            new Transaction(new double[] { 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 1, 0 }),
            new Transaction(new double[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0 }),
            new Transaction(new double[] { 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 1, 0, 0, 0, 1 })
        };


        TableGenerator.StudentTableToConsole(studentTransactions);
        TableOfTerms();
        var selected2 = ChoseItems();
        var shopSystem2 = new ShopSystem();
        shopSystem2.ListOfTransactions = studentTransactions;
        List<int> sugestion2 = shopSystem2.AddAndShowRecommendedItems(selected2, new double[] { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }, "Students");

        SugestItem(sugestion2, test3Names);
        Console.ReadKey();
    }





    static List<Transaction> GenerateDistance(List<Transaction> trans, string filename)
    {
        var cos = new MainClass();
        var generator = new GenerateDistances(cos.TableGenerator);
        var values = generator.GenerateChebysheveDistance(trans, false);
        var res = cos.TableGenerator.TextTableEnhanced(values, $"{filename}.txt", shopSystem.GenerateLineNames(trans.Count));
        Console.Write(res);
        Console.WriteLine("");

        return values;
    }
    static void TableOfProduct()
    {
        var table = new ConsoleTable(productNames);
        Console.WriteLine("Wybierz przedmiot: ");
        table.Options.EnableCount = false;
        table.Write();
    }

    static void TableOfTerms()
    {
        var table = new ConsoleTable(test3Names);
        Console.WriteLine("Wybierz co cie interesuje");
        table.Options.EnableCount = false;
        table.Write();
    }

    static Tuple<int, int>[] ChoseItems()
    {
        var items = new List<Tuple<int, int>>();

        while (true)
        {
            Console.WriteLine("Podaj ilość: (0 aby wyjść)");
            Console.WriteLine('>');
            var item = int.TryParse(Console.ReadLine(), out var itemNumber) ? itemNumber : 0;
            if (item == 0)
            {
                break;
            }

            items.Add(Tuple.Create(item, 1));
        }

        return items.ToArray();
    }

    static Tuple<int, int>[] ChoseItemsToBuy()
    {
        var items = new List<Tuple<int, int>>();

        while (true)
        {
            Console.WriteLine("Który przedmiot Cię interesuje? 0 to exit");
            Console.WriteLine('>');
            var item = int.TryParse(Console.ReadLine(), out var itemNumber) ? itemNumber : 0;
            if (item == 0)
            {
                break;
            }

            Console.WriteLine("Jaka ilość?");
            Console.WriteLine('>');
            var amount = int.TryParse(Console.ReadLine(), out var itemAmount) ? itemAmount : 0;
            if (amount == 0)
            {
                break;
            }

            items.Add(Tuple.Create(item, amount));
        }

        return items.ToArray();
    }

    static void SugestItem(List<int> itemsToSugest, string[] productNames)
    {
        Console.WriteLine("Polecane:");
        foreach (var item in itemsToSugest)
        {
            Console.WriteLine($"> {productNames[item + 1]}");
        }
    }

}
